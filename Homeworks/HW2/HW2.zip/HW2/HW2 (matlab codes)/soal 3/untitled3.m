clear;clc
s = tf('s')

T1 = 10.24/(s^2 + 4.41*s + 10.24)

step(T1)