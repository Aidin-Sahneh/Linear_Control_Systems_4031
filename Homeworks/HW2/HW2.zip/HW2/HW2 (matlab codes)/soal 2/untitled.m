clear;clc
s = tf('s')
% halghe baste 
 T1 = 0.4/(s + 0.8)
 %halghe baz 
 T2 = 0.4/(s + 0.4)
 
 hold on
 step(T1)
 step(T2)
 legend

 damp(T2)
 damp(T1)

Kp_open = dcgain(T2);
ess_open = 1 / (1 + Kp_open);

Kp_closed = dcgain(T1);
ess_closed = 1 / (1 + Kp_closed);

fprintf('خطای ماندگار سیستم حلقه باز برای ورودی پله: %.4f\n', ess_open);
fprintf('خطای ماندگار سیستم حلقه بسته برای ورودی پله: %.4f\n', ess_closed);


