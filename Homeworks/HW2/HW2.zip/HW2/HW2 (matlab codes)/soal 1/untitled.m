clear; clc;
s = tf('s');

T = 202.02577 / (s^2 + 5.67376*s + 127.86441);

G = T / (1 - T);
G = minreal(G); % ساده‌سازی تابع تبدیل

G


figure;
step(T);
title('Step Response of T');

figure;
step(G);
title('Step Response of G');
