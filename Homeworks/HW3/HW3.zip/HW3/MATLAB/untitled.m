clc
clear
close
n = 1:20;
npwA1 = -170000+32000.*(1.13.^n-1)./(0.13.*1.13.^n)+20000./1.13.^n;
npwA2 = -116400+32000.*(1.13.^n-1)./(0.13.*1.13.^n)-(2500/0.13).*((1.13.^n-
1)./(0.13.*1.13.^n)-n./1.13.^n);
hold on
plot(n,npwA1)
plot(n,npwA2)
legend('A1','A2')
xlabel('n')
ylabel('npw'