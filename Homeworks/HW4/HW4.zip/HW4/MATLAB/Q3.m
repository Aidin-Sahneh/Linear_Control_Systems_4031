s = tf('s');
g = tf([5 5], [5 1 0]);


delay_time = 2; % delay time
G = exp(-delay_time * s); 

final_g = g * G;


figure;
bode(g);
grid on;
title('Bode plot without exp');


figure;
bode(final_g);
grid on;
title('Bode plot with exp');
