
s = tf('s'); 

G1 = pade(exp(-2*s), 1)
G2 = 5 / (5 * s + 1) 
G3 = (s + 1) / s


G = G1 * G2 * G3;


figure;
bode(G);
title('Bode Plot of the System');


[GM, PM, ~, ~] = margin(G);
fprintf('Gain Margin: %.2f dB\n', 20*log10(GM));
fprintf('Phase Margin: %.2f degrees\n', PM);


if GM > 0 && PM > 0
    disp('The system is stable.');
else
    disp('The system is unstable.');
end
