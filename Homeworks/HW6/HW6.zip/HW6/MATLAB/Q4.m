clc
clear
close all

% Transfer functions
numerator_G = 3750;
denominator_G = [1, 25, 0];
G = tf(numerator_G, denominator_G);

numerator_C = [0.021, 1];
denominator_C = [0.007, 1];
C = tf(numerator_C, denominator_C);

% Combined system
G1 = minreal(series(C, G));

% Bode diagram
figure(1)
margin(G1)

% Step response
closed_loop = feedback(G1, 1); % Closed-loop transfer function
figure(2)
hold on
step(closed_loop)
step(tf(1))
legend('Step response of system', 'Step')

% Ramp response
figure(3)
hold on
step(minreal(tf(1,[1,0])*G1/((1+G1))))
step(tf(1,[1,0]))
title('Ramp Response')
legend('Ramp response of system', 'Ramp')
